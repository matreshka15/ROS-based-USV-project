#!/usr/bin/env python3
#The maximum distance, on which strategies to approach will take.
MaxDistance = 100
#--------串口设置-------------
SERIALPORT = '/dev/ttyTHS2'
baudrate = 115200
