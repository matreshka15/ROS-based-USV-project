#!/usr/bin/env python
# coding: utf-8

control_manual = 0
control_auto = 1
control_record = 2
mode_start_from_the_beginning = 0
mode_start_from_the_nearest = 1
#
control_mode_dict = {control_manual:'manual',control_auto:'auto',control_record:'recording'}
